-- SHOGHLAK initial schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create type public.app_role as enum ('owner','admin','moderator','employer','candidate');
create type public.job_status as enum ('draft','pending_review','published','paused','closed','rejected');
create type public.application_status as enum ('submitted','reviewing','shortlisted','interview','accepted','rejected','withdrawn');
create type public.company_status as enum ('pending','verified','rejected','suspended');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  city text,
  governorate text,
  headline text,
  bio text,
  education_level text,
  experience_years numeric(4,1) default 0,
  skills text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role public.app_role not null default 'candidate',
  created_at timestamptz not null default now()
);

create table public.companies (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete restrict,
  name text not null,
  description text,
  website text,
  industry text,
  city text,
  governorate text,
  logo_path text,
  status public.company_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name_ar text not null unique,
  name_en text,
  is_active boolean not null default true,
  sort_order integer not null default 0
);

create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  created_by uuid not null references auth.users(id) on delete restrict,
  category_id uuid references public.categories(id) on delete set null,
  title text not null,
  description text not null,
  employment_type text,
  workplace_type text,
  city text,
  governorate text,
  salary_min numeric(12,2),
  salary_max numeric(12,2),
  salary_currency text not null default 'EGP',
  experience_level text,
  education_level text,
  status public.job_status not null default 'pending_review',
  is_featured boolean not null default false,
  published_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint salary_range_valid check (salary_min is null or salary_max is null or salary_max >= salary_min)
);

create table public.resumes (
  id uuid primary key default gen_random_uuid(),
  candidate_id uuid not null references auth.users(id) on delete cascade,
  file_path text,
  title text,
  is_primary boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.applications (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  candidate_id uuid not null references auth.users(id) on delete cascade,
  resume_id uuid references public.resumes(id) on delete set null,
  cover_letter text,
  status public.application_status not null default 'submitted',
  employer_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(job_id, candidate_id)
);

create table public.saved_jobs (
  candidate_id uuid not null references auth.users(id) on delete cascade,
  job_id uuid not null references public.jobs(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(candidate_id, job_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_user_id uuid references auth.users(id) on delete set null,
  target_type text not null,
  target_id uuid not null,
  reason text not null,
  details text,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  plan_code text not null,
  status text not null default 'pending',
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create index jobs_status_published_idx on public.jobs(status, published_at desc);
create index jobs_location_idx on public.jobs(governorate, city);
create index jobs_category_idx on public.jobs(category_id);
create index applications_candidate_idx on public.applications(candidate_id, created_at desc);
create index applications_job_idx on public.applications(job_id, created_at desc);
create index companies_status_idx on public.companies(status);
create index notifications_user_idx on public.notifications(user_id, created_at desc);

-- Role helper: SECURITY DEFINER avoids recursive RLS lookups on user_roles.
create or replace function public.has_role(required_role public.app_role)
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = required_role
  );
$$;

create or replace function public.is_staff()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role in ('owner','admin','moderator')
  );
$$;

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.companies enable row level security;
alter table public.categories enable row level security;
alter table public.jobs enable row level security;
alter table public.resumes enable row level security;
alter table public.applications enable row level security;
alter table public.saved_jobs enable row level security;
alter table public.reports enable row level security;
alter table public.notifications enable row level security;
alter table public.subscriptions enable row level security;
alter table public.audit_logs enable row level security;

-- Profiles: users can read/update their own profile; staff can review.
create policy "profiles_select_own_or_staff" on public.profiles for select
using (id = auth.uid() or public.is_staff());
create policy "profiles_insert_own" on public.profiles for insert
with check (id = auth.uid());
create policy "profiles_update_own_or_staff" on public.profiles for update
using (id = auth.uid() or public.is_staff())
with check (id = auth.uid() or public.is_staff());

-- Roles: users can see their own role; only owner manages roles.
create policy "roles_select_self_or_owner" on public.user_roles for select
using (user_id = auth.uid() or public.has_role('owner'));
create policy "roles_owner_manage" on public.user_roles for all
using (public.has_role('owner')) with check (public.has_role('owner'));

-- Companies: public sees verified companies; owner can see/manage all; company owner manages own record.
create policy "companies_public_verified_or_staff_or_owner" on public.companies for select
using (status = 'verified' or owner_user_id = auth.uid() or public.is_staff());
create policy "companies_owner_insert" on public.companies for insert
with check (owner_user_id = auth.uid());
create policy "companies_owner_update_or_staff" on public.companies for update
using (owner_user_id = auth.uid() or public.is_staff())
with check (owner_user_id = auth.uid() or public.is_staff());

-- Categories are readable; staff manage.
create policy "categories_read_active_or_staff" on public.categories for select
using (is_active = true or public.is_staff());
create policy "categories_staff_manage" on public.categories for all
using (public.is_staff()) with check (public.is_staff());

-- Published jobs are public; employer sees own jobs; staff sees all.
create policy "jobs_read_published_or_owner_or_staff" on public.jobs for select
using (status = 'published' or created_by = auth.uid() or public.is_staff());
create policy "jobs_employer_insert" on public.jobs for insert
with check (
  created_by = auth.uid()
  and exists(select 1 from public.companies c where c.id = company_id and c.owner_user_id = auth.uid())
);
create policy "jobs_employer_update_or_staff" on public.jobs for update
using (created_by = auth.uid() or public.is_staff())
with check (created_by = auth.uid() or public.is_staff());
create policy "jobs_staff_delete" on public.jobs for delete
using (public.is_staff());

-- CVs are private to candidate and staff; employers should receive access only via application workflow.
create policy "resumes_select_owner_or_staff" on public.resumes for select
using (candidate_id = auth.uid() or public.is_staff());
create policy "resumes_insert_owner" on public.resumes for insert
with check (candidate_id = auth.uid());
create policy "resumes_update_owner_or_staff" on public.resumes for update
using (candidate_id = auth.uid() or public.is_staff())
with check (candidate_id = auth.uid() or public.is_staff());
create policy "resumes_delete_owner_or_staff" on public.resumes for delete
using (candidate_id = auth.uid() or public.is_staff());

-- Applications: candidate creates and sees own; employer sees applications to its jobs; staff sees all.
create policy "applications_select_related_or_staff" on public.applications for select
using (
  candidate_id = auth.uid()
  or public.is_staff()
  or exists (
    select 1 from public.jobs j
    join public.companies c on c.id = j.company_id
    where j.id = job_id and c.owner_user_id = auth.uid()
  )
);
create policy "applications_insert_candidate" on public.applications for insert
with check (candidate_id = auth.uid());
create policy "applications_update_related_or_staff" on public.applications for update
using (
  candidate_id = auth.uid()
  or public.is_staff()
  or exists (
    select 1 from public.jobs j
    join public.companies c on c.id = j.company_id
    where j.id = job_id and c.owner_user_id = auth.uid()
  )
)
with check (
  candidate_id = auth.uid()
  or public.is_staff()
  or exists (
    select 1 from public.jobs j
    join public.companies c on c.id = j.company_id
    where j.id = job_id and c.owner_user_id = auth.uid()
  )
);

create policy "saved_jobs_owner_manage" on public.saved_jobs for all
using (candidate_id = auth.uid()) with check (candidate_id = auth.uid());

create policy "reports_submit_authenticated" on public.reports for insert
with check (reporter_user_id = auth.uid());
create policy "reports_staff_read_update" on public.reports for select using (public.is_staff());
create policy "reports_staff_update" on public.reports for update
using (public.is_staff()) with check (public.is_staff());

create policy "notifications_owner_read" on public.notifications for select using (user_id = auth.uid());
create policy "notifications_owner_update" on public.notifications for update
using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "subscriptions_company_or_staff_read" on public.subscriptions for select
using (public.is_staff() or exists(select 1 from public.companies c where c.id = company_id and c.owner_user_id = auth.uid()));
create policy "subscriptions_staff_manage" on public.subscriptions for all
using (public.is_staff()) with check (public.is_staff());

create policy "audit_logs_staff_read" on public.audit_logs for select using (public.is_staff());
create policy "audit_logs_owner_insert" on public.audit_logs for insert
with check (public.has_role('owner'));
