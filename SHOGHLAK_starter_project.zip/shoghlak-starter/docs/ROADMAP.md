# SHOGHLAK delivery roadmap

## Phase 0 — Foundation
- Confirm brand assets, domain, privacy policy, terms, and data retention policy.
- Create owner-controlled GitHub, Supabase, and Vercel accounts.
- Apply database migration and verify RLS.

## Phase 1 — MVP web platform
- Candidate registration and profile.
- Company registration and verification queue.
- Job publishing and moderation.
- Search, filters, applications, saved jobs.
- Owner dashboard and audit log.
- Email notifications.

## Phase 2 — Mobile
- React Native + Expo apps for Android and iOS.
- Shared Supabase authentication and APIs.
- Push notifications and deep links.

## Phase 3 — Growth
- CV builder and AI-assisted CV feedback.
- Matching and recommendations.
- Employer subscriptions and featured listings.
- Analytics and reporting.

## Release gates
- No public launch before privacy/terms review.
- Test RLS with candidate, employer, moderator, and owner accounts.
- Test file upload access and private CV storage.
- Backups, error monitoring, rate limiting, abuse reporting, and incident plan.
- Verify all employer identities and moderate job listings.
