# Owner account setup

1. Create the first user through Supabase Auth using an email address you control.
2. In Supabase SQL Editor, identify the new user's UUID:
   ```sql
   select id, email from auth.users;
   ```
3. Promote only your own account:
   ```sql
   insert into public.user_roles (user_id, role)
   values ('YOUR-AUTH-USER-UUID', 'owner')
   on conflict (user_id) do update set role = 'owner';
   ```
4. Verify:
   ```sql
   select * from public.user_roles where user_id = 'YOUR-AUTH-USER-UUID';
   ```

Do not share your password, recovery codes, or Supabase service-role key. Enable MFA on GitHub, Supabase, Vercel, and your domain registrar. The `owner` role is powerful; do not assign it to contractors or ordinary moderators.

The initial web dashboard is a UI shell. Before public launch, implement and test server-side authorization for every write operation and add audit logging. RLS is enabled in the schema as a second layer of protection.
