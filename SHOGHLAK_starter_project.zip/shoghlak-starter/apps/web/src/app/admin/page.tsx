import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';

export default async function AdminPage() {
  let signedIn = false;
  let email = '';
  let configMissing = !process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!configMissing) {
    try {
      const supabase = await createClient();
      const { data } = await supabase.auth.getUser();
      signedIn = !!data.user;
      email = data.user?.email ?? '';
    } catch { /* show setup state */ }
  }
  return <main className="shell">
    <header className="top"><Link href="/" className="brand">SHOGHLAK <span>شُغلك</span></Link><span className="pill">مركز إدارة المالك</span></header>
    <section className="hero">
      <div className="eyebrow">OWNER CONTROL CENTER</div>
      <h1>لوحة تحكم شُغلك</h1>
      <p className="muted">إدارة الوظائف والشركات والباحثين عن عمل من مكان واحد.</p>
      {configMissing ? <p className="muted">اربط مشروع Supabase أولاً بإضافة متغيرات البيئة الموضحة في ملف README.</p> :
       signedIn ? <p className="muted">تم تسجيل الدخول بالحساب: {email}. الواجهة الحالية هي هيكل أولي؛ صلاحيات الإدارة الفعلية تُستكمل قبل الإطلاق.</p> :
       <p className="muted">لم يتم تسجيل الدخول. شاشة الدخول وربط صلاحية المالك ضمن خطوة الإعداد التالية.</p>}
    </section>
    <h2 className="section">نظرة عامة</h2>
    <section className="grid">
      {[
        ['الوظائف','—','إدارة ونشر الوظائف'],
        ['الشركات','—','التحقق من حسابات الشركات'],
        ['الباحثون عن عمل','—','إدارة ملفات المرشحين'],
        ['طلبات التوظيف','—','متابعة طلبات التقديم'],
      ].map(([title,value,desc])=><article className="card" key={title}><h3>{title}</h3><div className="num">{value}</div><p className="muted">{desc}</p></article>)}
    </section>
    <h2 className="section">أقسام الإدارة</h2>
    <section className="grid">
      {['إدارة الوظائف','إدارة الشركات','إدارة المستخدمين','طلبات التوظيف','التصنيفات','الاشتراكات','البلاغات','إعدادات المنصة'].map((x)=><article className="card" key={x}><h3>{x}</h3><p className="muted">سيتم تفعيل الوظائف بعد إعداد الصلاحيات والعمليات الآمنة.</p></article>)}
    </section>
    <p className="footer">تنبيه: لا تستخدم هذه اللوحة لإدارة بيانات حقيقية قبل استكمال المصادقة، صلاحيات الخادم، واختبارات RLS.</p>
  </main>;
}
