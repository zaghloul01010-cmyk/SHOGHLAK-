import Link from 'next/link';
export default function Home() {
  return <main className="shell">
    <header className="top"><div className="brand">SHOGHLAK <span>شُغلك</span></div><span className="pill">منصة التوظيف المصرية</span></header>
    <section className="hero">
      <div className="eyebrow">YOUR CAREER. YOUR OPPORTUNITY.</div>
      <h1>فرصتك تبدأ من هنا.</h1>
      <p className="muted">منصة واحدة تجمع الباحثين عن عمل بالشركات والفرص المناسبة في مصر.</p>
      <div className="actions"><Link className="btn" href="/admin">دخول لوحة الإدارة</Link><a className="btn secondary" href="#about">عن شُغلك</a></div>
    </section>
    <section id="about" className="card"><h2>SHOGHLAK — شُغلك</h2><p className="muted">نسخة التأسيس الأولية. سيتم إطلاق حسابات الباحثين عن عمل والشركات بعد استكمال التسجيل والتحقق وسياسات الخصوصية.</p></section>
    <p className="footer">© {new Date().getFullYear()} SHOGHLAK. جميع الحقوق محفوظة.</p>
  </main>;
}
