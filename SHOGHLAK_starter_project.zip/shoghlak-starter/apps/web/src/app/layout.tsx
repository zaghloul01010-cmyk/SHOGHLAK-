import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = {
  title: 'SHOGHLAK | شُغلك',
  description: 'منصة التوظيف المصرية — فرصتك تبدأ من هنا',
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
