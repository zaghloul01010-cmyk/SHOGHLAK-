# SHOGHLAK | شُغلك — Starter Project

A low-cost, owner-controlled foundation for an Egyptian jobs platform.

## Architecture
- `apps/web`: Next.js web app + owner admin dashboard.
- `supabase/migrations`: PostgreSQL schema, indexes, and Row Level Security (RLS).
- `docs`: setup, ownership, and launch notes.
- Mobile apps (Android/iOS) are intentionally a later phase; they will use the same Supabase backend.

## Requirements
- Node.js 20+
- A GitHub account owned by you
- A Supabase project owned by you
- A Vercel account owned by you (deployment later)

## 1. Run locally
```bash
cd apps/web
cp .env.example .env.local
npm install
npm run dev
```
Open http://localhost:3000.

The homepage and admin UI shell run without credentials. Supabase-backed login and protected data require the environment variables below.

## 2. Configure Supabase
1. Create a Supabase project using an email account you control.
2. In Supabase SQL Editor, run `supabase/migrations/0001_initial_schema.sql`.
3. Copy the Project URL and anon/public key into `apps/web/.env.local`.
4. In Supabase Authentication, enable email/password sign-in.
5. Create your own account through Supabase Auth, then set its role to `owner` using the SQL in `docs/OWNER_SETUP.md`.
6. Never expose the `service_role` key in browser code or commit it to GitHub.

Required environment variables:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

## 3. Owner access
Read `docs/OWNER_SETUP.md` before enabling admin access. The database uses RLS and a role table. Only the account you explicitly promote to `owner` can access owner-only operations.

## 4. Ownership checklist
- Create GitHub repository under your account/org.
- Create Supabase project under your account.
- Create Vercel project under your account.
- Keep recovery email, MFA, billing, and domain registrar under your control.
- Invite developers as collaborators with least privilege; do not transfer ownership.
- Keep `.env.local` private and out of Git.

## 5. Current scope
Included:
- Project structure and setup documentation.
- Initial database schema for profiles, companies, jobs, applications, resumes, categories, reports, notifications, subscriptions, and admin roles.
- RLS policies and basic role model.
- Arabic-first responsive dark admin dashboard shell.

Not yet included:
- Production authentication screens and complete server-side admin actions.
- Company verification workflow, job moderation, payments, AI CV tools, push notifications.
- Android/iOS apps, store publishing, production deployment, legal review, and security audit.

This is a starter foundation, not a production-ready hiring marketplace. Complete the remaining steps and test security before inviting real users.
